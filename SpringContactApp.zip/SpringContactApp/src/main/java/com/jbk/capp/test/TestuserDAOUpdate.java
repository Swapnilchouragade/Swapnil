package com.jbk.capp.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jbk.capp.config.SpringRootConfig;
import com.jbk.capp.dao.UserDAO;
import com.jbk.capp.domain.User;

public class TestuserDAOUpdate {
public static void main(String[] args) {
	

ApplicationContext ctx=new AnnotationConfigApplicationContext(SpringRootConfig.class);
UserDAO userdao=ctx.getBean(UserDAO.class);
User u=new User();
u.setUserid(1);
u.setName("amit");
u.setPhone("1234567890");
u.setEmail("Abc@gmail.com");
u.setAddress("pune");
u.setRole(1);
u.setLoginStatus(1);
userdao.update(u);
System.out.println("........data update ....");

   



}
	
	
}
