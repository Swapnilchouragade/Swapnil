package com.jbk.capp.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.jbk.capp.domain.User;
import com.jbk.capp.rm.UserRowMapper;
@Repository
public class UserDAOImpl extends BaseDAO implements UserDAO{

	public void save(User u) {
	System.out.println(u);
		// TODO Auto-generated method stub
		String sql="insert into user(name,phone,email,address,loginName,password,role,loginStatus)"
	+"values(:name,:phone,:email,:address,:loginName,:password,:role,:loginStatus)";
		Map m=new HashMap();
		m.put("name", u.getName());
		m.put("phone", u.getPhone());
		m.put("email", u.getEmail());
		m.put("address", u.getAddress());
		m.put("loginName", u.getLoginName());
		m.put("password", u.getPassword());
		m.put("role", u.getRole());
		m.put("loginStatus", u.getLoginStatus());
		
		KeyHolder kh=new GeneratedKeyHolder();
		SqlParameterSource ps=new MapSqlParameterSource(m);
		super.getNamedParameterJdbcTemplate().update(sql, ps,kh);
	Integer userId=kh.getKey().intValue();
	u.setUserid(userId);
	}

	public void update(User u) {
		// TODO Auto-generated method stub
		String sql="UPDATE user"
				+" SET name=:name,"
				+"phone=:phone,"
				+"email=:email,"
				+"address=:address,"
				+"role=:role,"
				+"loginStatus=:loginStatus "
				+"where userid=:userid";
		Map m=new HashMap();
		m.put("name", u.getName());
		m.put("phone", u.getPhone());
		m.put("email", u.getEmail());
		m.put("address", u.getAddress());
		m.put("role", u.getRole());
		m.put("loginStatus", u.getLoginStatus());
		m.put("userid",u.getUserid());
		getNamedParameterJdbcTemplate().update(sql, m);
	}

	public void delete(User u) {
		// TODO Auto-generated method stub
		this.delete(u.getUserid());
	}

	public void delete(Integer userid) {
		// TODO Auto-generated method stub
		String sql="Delete from user where userid=?";
		getJdbcTemplate().update(sql, userid);
	}

	public User findById(Integer userid) {
		// TODO Auto-generated method stub
		String sql ="select userid,name,phone,email,address,loginName,role,loginStatus" 
				+" from user where userid=?";
		User u=getJdbcTemplate().queryForObject(sql, new UserRowMapper(),userid);
	return u;
	}

	public List<User> findAll() {
		String sql ="select userid,name,phone,email,address,loginName,role,loginStatus" 
				+" from user ";
		List<User> u=getJdbcTemplate().query(sql, new UserRowMapper());
	return u;
	}

	public List<User> findByProperty(String propName, Object propvalue) {
		// TODO Auto-generated method stub
		
			String sql ="select userid,name,phone,email,address,loginName,role,loginStatus" 
					+" from user where "+propName+"=? ";
		return getJdbcTemplate().query(sql, new UserRowMapper(),propvalue);
	}

}
