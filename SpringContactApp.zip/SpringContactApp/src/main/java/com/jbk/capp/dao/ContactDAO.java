package com.jbk.capp.dao;

import java.util.List;

import com.jbk.capp.domain.Contact;
import com.jbk.capp.domain.User;

public interface ContactDAO {

	
		public void save(Contact c);
		public void update(Contact c);
		public void delete(Contact c);
		public void delete(Integer contactid);
		public void findById(Integer contactid);
		public List<Contact> findAll();
		public List<Contact> findByProperty(String propName,Object propvalue);
		}