package com.jbk.capp.service;

import java.util.List;

import com.jbk.capp.domain.Contact;

public interface ContactService {

	
	public void save(Contact c);
	public void update(Contact c);
	public void delete(Contact c);
	public void delete(Integer[] contactids);
	public List<Contact> findUserContact(Integer userid);
	public List<Contact> findUserContact(Integer userid,String txt);


}
