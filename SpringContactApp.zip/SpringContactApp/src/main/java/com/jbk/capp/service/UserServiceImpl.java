package com.jbk.capp.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jbk.capp.dao.BaseDAO;
import com.jbk.capp.dao.UserDAO;
import com.jbk.capp.domain.User;
import com.jbk.capp.exception.UserBlockException;
import com.jbk.capp.rm.UserRowMapper;


@Service
public class UserServiceImpl extends BaseDAO  implements UserService{
	
   @Autowired
	private UserDAO userdao;
	
@Override
	public void register(User u) {
		// TODO Auto-generated method stub
		userdao.save(u);
	}
@Override
	public User login(String loginName, String password) throws UserBlockException {
		// TODO Auto-generated method stub
	String sql="select userId,name,phone,email,address,role,loginStatus,loginname "
			+"from user where loginname=:ln  AND password=:pw";
	Map m=new HashMap();
	m.put("ln", loginName);
	m.put("pw",password);
	try{
User u=	getNamedParameterJdbcTemplate().queryForObject(sql,m,new UserRowMapper());
	if(u.getLoginStatus().equals(UserService.LOGIN_STATUS_BLOCKED))
	{
		throw new UserBlockException("contact to admin");
	}
		return u;
	}catch (EmptyResultDataAccessException e) {
		// TODO: handle exception
		return null;
	}	
	}
@Override
	public List<User> getUserList() {
		// TODO Auto-generated method stub
		return null;
	}
@Override
	public void changeLoginStatus(Integer userId, Integer loginStatus) {
		// TODO Auto-generated method stub
		
	}

	
	
	
}
