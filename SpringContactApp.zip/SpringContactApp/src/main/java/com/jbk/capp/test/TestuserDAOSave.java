package com.jbk.capp.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jbk.capp.config.SpringRootConfig;
import com.jbk.capp.dao.UserDAO;
import com.jbk.capp.domain.User;

public class TestuserDAOSave {
public static void main(String[] args) {
	

ApplicationContext ctx=new AnnotationConfigApplicationContext(SpringRootConfig.class);
UserDAO userdao=ctx.getBean(UserDAO.class);
User u=new User();
u.setName("swapnil");
u.setPhone("1234567890");
u.setEmail("Abc@gmail.com");
u.setAddress("mumbai");
u.setLoginName("amit");
u.setPassword("123456");
u.setRole(1);
u.setLoginStatus(1);
userdao.save(u);
System.out.println("........data save ....");

   



}
	
	
}
