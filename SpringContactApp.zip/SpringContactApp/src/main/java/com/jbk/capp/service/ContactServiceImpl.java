package com.jbk.capp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.jbk.capp.dao.BaseDAO;
import com.jbk.capp.dao.ContactDAO;
import com.jbk.capp.domain.Contact;
import com.jbk.capp.rm.ContactRowMapper;
import com.jbk.capp.utility.StringUtil;

public class ContactServiceImpl extends BaseDAO implements ContactService{
@Autowired
	private ContactDAO contactdao;
	@Override
	public void save(Contact c) {
		contactdao.save(c);
	}

	@Override
	public void update(Contact c) {
		contactdao.update(c);
	}

	@Override
	public void delete(Contact c) {
contactdao.delete(c);		
	}

	@Override
	public void delete(Integer[] contactids) {
String ids=StringUtil.toCommandSeparatedSring(contactids);
		String sql="DELETE from contact WHERE contactid IN("+ids+")";
	getJdbcTemplate().update(sql);
	}

	@Override
	public List<Contact> findUserContact(Integer userid) {

		return  contactdao.findByProperty("userId", userid);
		
	}

	@Override
	public List<Contact> findUserContact(Integer userid, String txt) {
		String sql=" select contactid,name,phone,email,address,remark from contact WHERE userid=? AND (name LIKE '%"+txt+"%' OR address LIKE '%"+txt+"%' OR phone LIKE '%"+txt+"%' OR email LIKE '%"+txt+"%' OR remark LIKE '%"+txt+"%')";
		return	getJdbcTemplate().query(sql, new ContactRowMapper(), userid); 
	}

}
