package com.jbk.capp.exception;

public class UserBlockException extends Exception{

	
	
	public UserBlockException()
	{
		
	}
	public UserBlockException(String e)
	{
		super(e);
	}
}
