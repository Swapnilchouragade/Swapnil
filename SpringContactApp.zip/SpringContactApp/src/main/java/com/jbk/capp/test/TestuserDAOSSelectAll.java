package com.jbk.capp.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jbk.capp.config.SpringRootConfig;
import com.jbk.capp.dao.UserDAO;
import com.jbk.capp.domain.User;

public class TestuserDAOSSelectAll {
public static void main(String[] args) {
	

ApplicationContext ctx=new AnnotationConfigApplicationContext(SpringRootConfig.class);
UserDAO userdao=ctx.getBean(UserDAO.class);
List<User> u=userdao.findAll();
for(User ulist:u)
{
System.out.println(ulist.getName());
}
System.out.println("........data select ....");

   



}
	
	
}
