package com.jbk.capp.rm;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.jbk.capp.domain.User;

public class UserRowMapper  implements RowMapper<User>
{

	public User mapRow(ResultSet rs, int i) throws SQLException {
		// TODO Auto-generated method stub
		User u=new User();
		u.setUserid(rs.getInt("userid"));
		u.setName(rs.getString("name"));
		u.setEmail(rs.getString("Email"));
		u.setAddress(rs.getString("address"));
		u.setLoginName(rs.getString("loginName"));
		u.setRole(rs.getInt("role"));
		u.setLoginStatus(rs.getInt("loginStatus"));
		
		return u;
	}

}
