package com.jbk.capp.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jbk.capp.command.LoginCommand;
import com.jbk.capp.domain.User;
import com.jbk.capp.service.UserService;

@Controller
public class UserController {
@Autowired
	private UserService userservice;

//........................................................................
	@RequestMapping(value={"/","/index"})
	public String index(Model m)
	{
	//	public
		m.addAttribute("command", new LoginCommand());
		return "index";  //Jsp
	}

//........................................................................................
	@RequestMapping(value={"/login"} ,method=RequestMethod.POST)
	public String handleLogin(@ModelAttribute("command") LoginCommand cmd,Model m,HttpSession session)
	{
		System.out.println(1111);
		try{
	User loggedInUser=	userservice.login(cmd.getLoginName(), cmd.getPassword());
		if(loggedInUser==null)
		{m.addAttribute("err","login falid");
		return "index";
			
		}else {
			//check the role
			if(loggedInUser.getRole().equals(UserService.ROLE_ADMIN))
			{
				//add user details in session  assign seesion to in admin
			/*	System.out.println("role admin ......."+UserService.ROLE_ADMIN);
			System.out.println("loggedInUser.getRole..."+loggedInUser.getRole());*/
				addUserInSession(loggedInUser, session);
				return "redirect:admin/dashboard";
			}else if(loggedInUser.getRole().equals(UserService.ROLE_USER))
            {
				//add user details in session  assign seesion to in user
				addUserInSession(loggedInUser, session);
				return "redirect:user/dashboard";
			}else {
				m.addAttribute("err","invalde user role");
				return "index";
			}
		}
		}catch (Exception e) {
			// TODO: handle exception
			m.addAttribute("err",e.getMessage());
			return "index";
		}
		
	}
	
	//.........................................
	@RequestMapping(value={"/user/dashboard"})
	public String userDashboard()
	{
		
		return "dashboard_user"; //Jsp
	}
	//.................................................
	
	//.................................................
	@RequestMapping(value={"/admin/dashboard"})
	public String adminDashboard()
	{
		
		return "dashboard_admin"; //Jsp
	}
	
	//.................................................
	@RequestMapping(value="/logout")
	public String logout(HttpSession session)
	{
		session.invalidate();
		return "redirect:index?act=lo"; //Jsp
	}
	
	private void addUserInSession(User u, HttpSession session)
	{
		session.setAttribute("user", u);
		session.setAttribute("userId", u.getUserid());
		session.setAttribute("role", u.getRole());
		System.out.println("userid..."+session.getAttribute("userId"));
		System.out.println("role..."+session.getAttribute("role"));
	}
	
}
