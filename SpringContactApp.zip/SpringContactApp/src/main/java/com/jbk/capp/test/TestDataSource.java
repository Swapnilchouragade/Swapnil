package com.jbk.capp.test;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import com.jbk.capp.config.SpringRootConfig;

public class TestDataSource {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		ApplicationContext ctx= new AnnotationConfigApplicationContext(SpringRootConfig.class);
DataSource ds=ctx.getBean(DataSource.class);
JdbcTemplate jt=new  JdbcTemplate(ds);
String sql="insert into user(name,phone,email,address,loginName,password)values(?,?,?,?,?,?)";
	Object[] param=new Object[]{"swapnil","1234567890","Swapnil@gmail.com","pune","root","root"};
	jt.update(sql,param);
	System.out.println("done executed");
	}

}
