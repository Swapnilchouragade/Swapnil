package com.jbk.capp.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jbk.capp.config.SpringRootConfig;
import com.jbk.capp.dao.UserDAO;
import com.jbk.capp.domain.User;

public class TestuserDAOSelect {
public static void main(String[] args) {
	

ApplicationContext ctx=new AnnotationConfigApplicationContext(SpringRootConfig.class);
UserDAO userdao=ctx.getBean(UserDAO.class);
User u=userdao.findById(3);
System.out.println(u.getName());
System.out.println("........data select ....");

   



}
	
	
}
