package com.jbk.capp.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jbk.capp.config.SpringRootConfig;
import com.jbk.capp.dao.UserDAO;
import com.jbk.capp.domain.User;
import com.jbk.capp.service.UserService;
import com.jbk.capp.service.UserServiceImpl;

public class TestUserServiceRegister {
public static void main(String[] args) {
	

ApplicationContext ctx=new AnnotationConfigApplicationContext(SpringRootConfig.class);
System.out.println(1);
//UserServiceImpl userservice=ctx.getBean(UserServiceImpl.class);
UserService userservice=new UserServiceImpl();
System.out.println(2);
User u=new User();
System.out.println(3);
u.setName("swapnilffff");
u.setPhone("1234567440");
u.setEmail("Abcx@gmail.com");
u.setAddress("punr");
u.setLoginName("aaaa");
u.setPassword("123aa456");
u.setRole(UserService.ROLE_USER);
u.setLoginStatus(UserService.LOGIN_STATUS_ACTIVE);
userservice.register(u);
System.out.println("........data register ....");

   



}
	
	
}
