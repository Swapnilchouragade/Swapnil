package com.jbk.capp.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.plaf.basic.BasicComboBoxUI.KeyHandler;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.jbk.capp.domain.Contact;
import com.jbk.capp.rm.ContactRowMapper;

public class ContactDAOImpl  extends BaseDAO implements ContactDAO{

	public void save(Contact c) {
		// TODO Auto-generated method stub
		String sql="insert into contact (userid,name,phone,email,address,remark)values(:userid,name:,:phone,:email,:address,:remark)";
	Map m=new HashMap();
	m.put("userid", c.getUserid());
	m.put("name", c.getName());
	m.put("phone", c.getPhone());
	m.put("email", c.getEmail());
	m.put("address", c.getAddress());
	m.put("remark", c.getRemark());
	SqlParameterSource ps=new MapSqlParameterSource(m);
	KeyHolder kh=new GeneratedKeyHolder();
	getNamedParameterJdbcTemplate().update(sql, ps,kh);
	}

	public void update(Contact c) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		String sql="update  contact set userid=:userid,name=:name,phone=:phone,email=:email,address=:address,remark=:remark where contactid=:contactid";
	Map m=new HashMap();
	m.put("contactid", c.getContactId());
	m.put("name", c.getName());
	m.put("phone", c.getPhone());
	m.put("email", c.getEmail());
	m.put("address", c.getAddress());
	m.put("remark", c.getRemark());

	getNamedParameterJdbcTemplate().update(sql, m);
	}


	public void delete(Contact c) {
		// TODO Auto-generated method stub
		this.delete(c.getContactId());
		
	}

	public void delete(Integer contactid) {
		// TODO Auto-generated method stub
		String  sql="delete frome contact  where contactid=?";
		getJdbcTemplate().update(sql,contactid);
	}

	public void findById(Integer contactid) {
		// TODO Auto-generated method stub
		String sql=" select userid,name,phone,email,address,remark from contact where contactid=?" ;
	getJdbcTemplate().queryForObject(sql, new ContactRowMapper(),contactid);
	}

	public List<Contact> findAll() {
		// TODO Auto-generated method stub
		String sql=" select contactid,name,phone,email,address,remark from contact";
	return	getJdbcTemplate().query(sql, new ContactRowMapper());
		
	}

	public List<Contact> findByProperty(String propName, Object propvalue) {
		String sql=" select contactid,name,phone,email,address,remark from contact where contactid="+propName+"" ;
return		getJdbcTemplate().query(sql, new ContactRowMapper(),propvalue);
		}

}
