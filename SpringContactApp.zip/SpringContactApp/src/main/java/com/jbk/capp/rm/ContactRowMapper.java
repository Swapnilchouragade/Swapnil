package com.jbk.capp.rm;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.jbk.capp.domain.Contact;

public class ContactRowMapper  implements RowMapper<Contact>
{

	public Contact mapRow(ResultSet rs, int i) throws SQLException {
		// TODO Auto-generated method stub
		Contact c=new Contact();
		c.setContactId(rs.getInt("userid"));
		c.setUserid(rs.getString("userId"));
		c.setName(rs.getString("name"));
		c.setEmail(rs.getString("Email"));
		c.setAddress(rs.getString("address"));
		c.setPhone(rs.getString("phone"));
		c.setRemark(rs.getString("remark"));

		return c;
	}

}
